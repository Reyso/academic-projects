#define F_CPU 8000000UL
#include <avr/io.h>
int main(void)
{	DDRB = 0x00; //todos os pinos s�o entradas
	//PORTB = 0b0000.1000 // 0x08 PB3 NIvel logico alto // PORTB = 1<<PB3; (1<<PB3) = 0000.1000 = 0X08 = 8 
	//DDRC = 0b0000.0100 // 0x04 Sa�da na porta C (para o LED)
	PORTB = 1<<PB3;
	DDRC = 1<<PC2;
	while(1) //la�o infinito
	{if(PINB& 0x08) // Verifica PB3	(adiciona o 1 ao pb3)
		PORTC |= 1<<PC2;//liga PB5
		else
		PORTC &=~(1<<PB5); // Desliga PB5
	}
}
//  mudar a chave para o pino pb3
// para ativar pull-up interno (DDRx 0 e PORTx 1)





//#include <avr/io.h>
//int main(void)
//{	DDRB = 0x20; //Pino PB5 sa�da
//
//	while(1) //la�o infinito
//	{if(PINB& 0x04) // Verifica PB2
//		PORTB&= ~(1<<PB5);//Desliga PB5
//		else
//		PORTB|= 1<<PB5; //Liga PB5
//	}
//}