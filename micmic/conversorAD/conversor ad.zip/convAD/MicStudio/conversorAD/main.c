 #define F_CPU 8000000UL
 #include <avr/io.h>
 #include <util/delay.h>
 #include "adc.h"
 #include "uart.h"
  
 /*
 Neste exemplo, uma tens�o
 aplicada ao pinoADC0 (PC0)
 dever� ser convertida e o valor
 enviado para a porta UART.
 */
 
 /*
  int main(void)
 { uint16_t valorADC;
	 uartBegin(9600, F_CPU);//Inicializa UART
	 adcBegin(AVCC,0x01); //Inicializa A/D
	 adcChannel(ADC0); //seleciona entrada
	 while(1) //la�o infinito
	 {valorADC = adcRead();//l� o valor anal�gico
		 uartDec2B(valorADC);//envia valor lido
		 uartString("\r\n"); //nova linha
		 _delay_ms(200); //aguarda
	 }
 }*/
 
 // COM interrup��o
 /*
 Neste exemplo, a convers�o da
 tens�o aplicada ao pino ADC0
 (PC0)� iniciada quando recebe aletra �C� pela porta UART
 .A leitura do valor convertido �
 lido ap�s interrup��o de fim da  convers�o.
 */
 
 int main(void)
 { uartBegin(9600, F_CPU); //Inicializa UART
	 adcBegin(AVCC, 0x01); //Inicializa A/D
	 adcChannel(ADC0); //Seleciona canal
	 adcIntEn(1); //Interrup��o do A/D
	 sei(); //Interrup��o geral
	 while (1)
	 { if (uartRxOk()) //verifica se existe novo dado na uart
		 if (uartRx() == 'C')//Se sim, verifica se foi 'C'
		 adcSample(); //Inicia convers�o
	 }
 }
 //Tratamendo da interrup��o do A/D
 ISR(ADC_vect)
 { uartString("Valor: ");   //Envia string
	 uartDec2B(adcReadOnly());//Ler e envia valor do A/D
	 uartString("\r\n"); //Nova linha
 }